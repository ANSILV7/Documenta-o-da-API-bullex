"""Module for Bullex API websocket received."""
