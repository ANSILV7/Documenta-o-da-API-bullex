"""Module for Bullex API websocket objects."""
