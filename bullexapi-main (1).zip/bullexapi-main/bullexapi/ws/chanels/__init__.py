"""Module for Bullex API websocket chanels."""
